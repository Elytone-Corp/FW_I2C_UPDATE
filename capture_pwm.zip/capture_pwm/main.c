

//*********************************STABLE_CODE_STABLE_PWM_DETECT & CLASSIFICATION**************************************


//
//
//#include <stdio.h>
//#include "mxc_device.h"
//#include "gpio.h"
//#include "tmr.h"
//#include "nvic_table.h"
//#include "mxc_delay.h"
//#include "uart.h"
//
//#define PWM_INPUT_PIN      2  // This is P0_2, connected to the PWM signal
//#define BUTTON_PIN         1  // Button connected to P0_1
//#define TMR_IDX            0  // Use Timer 0
//
//volatile uint32_t risingEdge1 = 0, fallingEdge = 0, period = 0;
//volatile uint32_t highTime = 0;
//volatile float dutyCycle = 0.0;
//volatile int measurementReady = 0;
//volatile int currentClass = -1;
//volatile int classificationLocked = 0;
//volatile int buttonPressed = 0;
//volatile uint32_t debounceTime = 0;
//
//void PWM_Handler(void* cbdata);
//void Button_Handler(void* cbdata);
//
//void GPIO_Init(void) {
//    mxc_gpio_cfg_t gpio_cfg_pwm = {
//        .port = MXC_GPIO0,
//        .mask = (1 << PWM_INPUT_PIN),
//        .pad = MXC_GPIO_PAD_NONE,
//        .func = MXC_GPIO_FUNC_IN
//    };
//    MXC_GPIO_Config(&gpio_cfg_pwm);
//
//    mxc_gpio_cfg_t gpio_cfg_button = {
//        .port = MXC_GPIO0,
//        .mask = (1 << BUTTON_PIN),
//        .pad = MXC_GPIO_PAD_PULL_UP,
//        .func = MXC_GPIO_FUNC_IN
//    };
//    MXC_GPIO_Config(&gpio_cfg_button);
//
//    // Register and enable interrupts
//    MXC_GPIO_RegisterCallback(&gpio_cfg_pwm, PWM_Handler, NULL);
//    MXC_GPIO_IntConfig(&gpio_cfg_pwm, MXC_GPIO_INT_BOTH);
//    MXC_GPIO_EnableInt(gpio_cfg_pwm.port, gpio_cfg_pwm.mask);
//
//    MXC_GPIO_RegisterCallback(&gpio_cfg_button, Button_Handler, NULL);
//    MXC_GPIO_IntConfig(&gpio_cfg_button, MXC_GPIO_INT_FALLING);
//    MXC_GPIO_EnableInt(gpio_cfg_button.port, gpio_cfg_button.mask);
//
//    NVIC_EnableIRQ(MXC_GPIO_GET_IRQ(MXC_GPIO_GET_IDX(MXC_GPIO0)));
//}
//
//void Timer_Init(void) {
//    mxc_tmr_cfg_t tmr_cfg;
//
//    MXC_TMR_Stop(MXC_TMR_GET_TMR(TMR_IDX));
//
//    tmr_cfg.pres = MXC_TMR_PRES_1;
//    tmr_cfg.mode = MXC_TMR_MODE_CONTINUOUS;
//    tmr_cfg.cmp_cnt = 0;
//    tmr_cfg.pol = 0;
//
//    MXC_TMR_Init(MXC_TMR_GET_TMR(TMR_IDX), &tmr_cfg);
//    MXC_TMR_Start(MXC_TMR_GET_TMR(TMR_IDX));
//}
//
//void PWM_Handler(void* cbdata) {
//    uint32_t current_time = MXC_TMR_GetCount(MXC_TMR_GET_TMR(TMR_IDX));
//
//    if (MXC_GPIO_InGet(MXC_GPIO0, (1 << PWM_INPUT_PIN))) {
//        if (risingEdge1 == 0) {
//            risingEdge1 = current_time;
//        } else {
//            period = current_time - risingEdge1;
//            risingEdge1 = current_time;
//            measurementReady = 1;
//        }
//    } else {
//        fallingEdge = current_time;
//        highTime = fallingEdge - risingEdge1;
//    }
//}
//
//void Button_Handler(void* cbdata) {
//    if (!buttonPressed) {
//        buttonPressed = 1;
//        debounceTime = MXC_TMR_GetCount(MXC_TMR_GET_TMR(TMR_IDX));
//    } else if (buttonPressed && (MXC_TMR_GetCount(MXC_TMR_GET_TMR(TMR_IDX)) - debounceTime > 10000)) {
//        if (classificationLocked) {
//            classificationLocked = 0;
//            currentClass = -1;
//            buttonPressed = 0;
//        }
//    }
//}
//
//void Process_PWM(void) {
//    if (measurementReady) {
//        measurementReady = 0;
//
//        dutyCycle = ((float)highTime / period) * 100.0;
//
//        // Handle possible high duty cycles (near 90%)
//        if (dutyCycle > 95.0) {
//            dutyCycle = 90.0;
//        }
//
//        // Define ranges based on the new logic (I used 4 units)
//        const float requiredDutyCycleRanges[4][2] = {
//            {23.0, 28.0},  // 25% duty cycle range
//            {48.0, 53.0},  // 50% duty cycle range
//            {73.0, 78.0},  // 75% duty cycle range
//            {88.0, 92.0}   // 90% duty cycle range
//        };
//
//        // Classification logic
//        for (int i = 0; i < 4; i++) {
//            if (dutyCycle >= requiredDutyCycleRanges[i][0] && dutyCycle <= requiredDutyCycleRanges[i][1]) {
//                if (i != currentClass) {
//                    float classifiedDuty = (i + 1) * 22.5;
//                    if (i == 0) classifiedDuty = 25;
//                    if (i == 1) classifiedDuty = 50;
//                    if (i == 2) classifiedDuty = 75;
//                    if (i == 3) classifiedDuty = 90;
//
//                    printf("Measured Duty Cycle: %.2f%%\n", dutyCycle);
//                    printf("----------  ");
//                    printf("Classified as =====>> %.0f%% duty cycle\n", classifiedDuty);
//                    currentClass = i;
//                    classificationLocked = 1;
//                }
//                break;
//            }
//        }
//    }
//}
//
//int main(void) {
//    GPIO_Init();
//    Timer_Init();
//
//    // Initial classification right after start
//    printf("STARING_____ AT :--> \n");
//    Process_PWM();
//
//    while (1) {
//        if (!classificationLocked) {
//            Process_PWM();
//        }
//        MXC_Delay(MXC_DELAY_MSEC(250));
//    }
//
//    return 0;
//}

//*********************************************-----**********************************************************


// CAPTURE PATERN in SEQUENCE PWM ----->
#include <stdio.h>
#include <string.h>
#include "mxc_device.h"
#include "gpio.h"
#include "tmr.h"
#include "nvic_table.h"
#include "mxc_delay.h"
#include "board.h"

// Configuration Macros
#define NUM_SAMPLES 50
#define START_BIT_THRESHOLD 25

// Global Variables
int samples[NUM_SAMPLES];
int sample_index = 0;
float weighted_avg = 0;
int start_bit_locked = 0;
int active_port_detected = 0;

// Function Declarations
void calculate_weighted_avg(void);
void detect_pd_class(void);
void GPIO_Init(void);
void Timer_Init(void);
void Enter_Low_Power_Mode(void);
void TMR1_IRQHandler(void);
void TMR2_IRQHandler(void);

// GPIO Initialization
void GPIO_Init(void) {
    mxc_gpio_cfg_t gpio_cfg = {
        .port = MXC_GPIO0,               // Port detection logic here
        .mask = MXC_GPIO_PIN_13,         // Pin 13 for input signal
        .func = MXC_GPIO_FUNC_IN,        // Set as input
        .pad = MXC_GPIO_PAD_NONE,        // No pull-up or pull-down
        .vssel = MXC_GPIO_VSSEL_VDDIOH   // Voltage select
    };
    MXC_GPIO_Config(&gpio_cfg);
}

// Timer Initialization
void Timer_Init(void) {
    // Timer 1 configuration for capturing the signal
    mxc_tmr_cfg_t tmr_cfg = {
        .mode = MXC_TMR_MODE_CAPTURE,
        .cmp_cnt = 0,                    // Not used in capture mode
        .pres = MXC_TMR_PRES_64           // Prescaler to adjust the timer speed
    };

    MXC_TMR_Init(MXC_TMR1, &tmr_cfg);
    MXC_NVIC_SetVector(TMR1_IRQn, TMR1_IRQHandler);
    NVIC_EnableIRQ(TMR1_IRQn);
    MXC_TMR_Start(MXC_TMR1);

    // Timer 2 configuration for processing
    tmr_cfg.mode = MXC_TMR_MODE_CONTINUOUS;
    tmr_cfg.cmp_cnt = MXC_TMR_GetPeriod(MXC_TMR2, MXC_TMR_PRES_64, 1000); // 1ms period

    MXC_TMR_Init(MXC_TMR2, &tmr_cfg);
    MXC_NVIC_SetVector(TMR2_IRQn, TMR2_IRQHandler);
    NVIC_EnableIRQ(TMR2_IRQn);
    MXC_TMR_Start(MXC_TMR2);
}


// Start Bit Detection
int detect_start_bit(int sample) {
    if (sample == START_BIT_THRESHOLD) {
        start_bit_locked = 1;
        return 1;  // Start bit detected
    }
    return 0;  // Start bit not detected
}

// Timer 1 Interrupt Handler for Sample Capture
void TMR1_IRQHandler(void) {
    MXC_TMR_ClearFlags(MXC_TMR1);

    if (!start_bit_locked && detect_start_bit(MXC_GPIO_InGet(MXC_GPIO0, MXC_GPIO_PIN_13))) {
        start_bit_locked = 1;
    }

    if (start_bit_locked && sample_index < NUM_SAMPLES) {
        samples[sample_index++] = MXC_GPIO_InGet(MXC_GPIO0, MXC_GPIO_PIN_13);
    } else if (sample_index >= NUM_SAMPLES) {
        calculate_weighted_avg();
        detect_pd_class();
        sample_index = 0;
        start_bit_locked = 0; // Reset start bit lock for next cycle
    }
}

// Timer 2 Interrupt Handler for Processing
void TMR2_IRQHandler(void) {
    MXC_TMR_ClearFlags(MXC_TMR2);

    // Implement any background processing tasks here if needed
}

// Weighted Average Calculation
void calculate_weighted_avg(void) {
    const int weights[5] = {1, 2, 3, 2, 1};
    float weighted_sum = 0;

    for (int i = 0; i < 5; i++) {
        weighted_sum += samples[i] * weights[i];
    }

    weighted_avg = weighted_sum / 9;
}

// PD Class Detection
void detect_pd_class(void) {
    // PD Class Detection Logic
    if (weighted_avg < 1.8) {
        // PD Class 4
    } else if (weighted_avg < 2.3) {
        // PD Class 5
    } else if (weighted_avg < 2.4) {
        // PD Class 6
    } else if (weighted_avg < 2.5) {
        // PD Class 7
    } else {
        // PD Class 8
    }
}

// Main Function
int main(void) {

	MXC_Delay(5);
    SystemInit();
    GPIO_Init();
    Timer_Init();

    while (1) {

    	MXC_Delay(50000); //for tera term


    }

    return 0;
}
